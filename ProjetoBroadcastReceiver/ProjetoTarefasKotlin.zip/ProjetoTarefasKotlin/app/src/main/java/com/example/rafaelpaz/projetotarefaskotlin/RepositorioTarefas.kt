package com.example.rafaelpaz.projetotarefaskotlin

object RepositorioTarefas {
    var tarefas: ArrayList<Tarefa> = ArrayList()

}