package com.example.rafaelpaz.projetotarefaskotlin


import java.io.Serializable


data class Tarefa(var titulo: String?, var descricao: String?, var feito: Boolean?) : Serializable